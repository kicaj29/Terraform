$env:TF_LOG="TRACE"
$env:TF_LOG_PATH="D:\temp\tf_logs\terraform.log"
terraform apply